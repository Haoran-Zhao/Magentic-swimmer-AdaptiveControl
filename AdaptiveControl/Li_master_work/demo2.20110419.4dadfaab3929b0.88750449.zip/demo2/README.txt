﻿This is the demo file for L1 adaptive controller with unknown parameter, unknown disturbance, unknown control effectiveness:
\dot x(t) = Ax(t) + b(\omega u(t) + \theta(t)^\top x(t) + \sigma(t))


DoSims.m: This script initializes the model parameters, run the simulation. You can split the parts you need and do the simulations according to your interest.



L1Model_sec2.mdl:the implementation of the system.






Refer to the following paper for background: 

C. Cao, and N. Hovakimyan, “L1 adaptive controller for systems with unknown time-varying parameters and disturbances in the presence of non-zero trajectory initialization error”, International Journal of Control, Vol. 81, No. 7, 1147–1161, July 2008