% This script demonstrate the L1 controller under:
% 1. Different theta and sigma
% 2. Time delay
% 3. Non-zero initialization error
% Most parts of the script are plotting, and you can trim the script based
% on your interests.

clear all;
close all;
clc;
%% Setting up

Am=[0 1; -1 -1.4];
b=[0;1];
c=[1;0]';
w=1;
r=1;
% Computation
kg=-1/(c*inv(Am)*b);
P=lyap(Am',eye(2));
Pb=P*b;

%% Simulations
TIME=25;

%things you can tune
x0=[0;0]; xhat_0=[0;0];  % you can set non-zero initialization error

tau=0.015;  % time delay

Gamma=100000; % you can change adaptive gain
PbG=Pb*Gamma;

theta_switch = 1; % you can use different theta

sigma_switch=1;  % you can use different sigma

%projection bound for sigma
Delta=50;

Omegaproj=2;

k=60;

Ds=ss(tf([1],[1 0])); %filter D(s)

open('L1Model_sec2');
sim('L1Model_sec2');


