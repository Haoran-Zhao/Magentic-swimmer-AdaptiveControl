This is the demo file for Rhors' counter example: adaptive control for system with unmodeled dynamics, which show the lack of robustness of the traditional MRAC.



DoSims.m: This script initializes the model parameters, run the simulation, and plot all the results automatically.



L1Model_Rohrs.mdl:the implementation of L1 adaptive controller.

MracModel_Rohrs.mdl: the implementation of the traditional MRAC.



Refer to the following papers for background:



C.E. Rohrs, L. Valavani, M. Athans, and G. Stein, "Stability Problems of Adaptive Control Algorithms in the Pressence of Unmodeled Dynamics", 21st Conference on Decision and Control, Dec 1982.



Enric Xargay,  Naira Hovakimyan and  Chengyu Cao, "Benchmark Problems of Adaptive Control Revisited by L1 Adaptive Control", International Symposium on Intelligent Control and 17th Mediterranean Conference on Control and Automation, Thessaloniki, Greece, June 24-26, 2009, pp. 31-36.
