% This script compares the performance of MRAC and L1 controller
% under 2 reference input signals (see the switch in the model file). 


close all
clear all
clc
%% Setting up
%System
Plant = tf([2],[1 1])*tf([229],[1 30 229]);
%MRAC
RefModel = tf([3],[1 3]);
xm_0 = 0;
x_0 = 0;
kr0 = 1.14;
kx0 = -0.65;
%L1
StatePredictor = tf([2],[1 3]);
Prb   = 10;
Prbu  = 2.5;
Prbuc = 2.5+0.5;
Gamma=1000;
k=5;
kg=3/2;
khatx0 = 0.65;
khats0 = 0;
khatu0 = 1.14;
xhat_0 = x_0;
%Simparam
TIME=20;


%% Computation
%MRAC
Plantss = ss(Plant);
RefModelss = ss(RefModel);
%L1
StatePredictorss = ss(StatePredictor);
%% Bode
bode(Plant);
[Gm,Pm,Wg,Wp] = margin(Plant);
Gm_dB = 20*log10(Gm);
disp(['Pm = ',num2str(Pm),' [deg], Gm = ',num2str(Gm_dB),' [dB], w_cg = ',num2str(Wp),' [rad/s], w_cp = ',num2str(Wg),' [rad/s]']);
grid on;

%% Simmulations for MRAC
%First control input

open('MracModel_Rohrs');
sim('MracModel_Rohrs');


%Second control input
open('L1Model_Rohrs')
sim('L1Model_Rohrs')

